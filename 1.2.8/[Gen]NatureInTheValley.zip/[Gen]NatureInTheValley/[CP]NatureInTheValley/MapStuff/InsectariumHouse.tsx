<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="InsectariumHouse" tilewidth="16" tileheight="16" tilecount="255" columns="17">
 <image source="InsectariumHouse.png" width="280" height="250"/>
</tileset>
